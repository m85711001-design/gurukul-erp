-- GURUKUL UNIVERSAL SCHOOL ERP - Phase 1 schema
create extension if not exists pgcrypto;

create type user_role as enum ('admin','accountant');
create type payment_mode as enum ('cash','upi','bank_transfer','cheque','other');
create type payment_status as enum ('completed','cancelled','refunded');
create type discount_type as enum ('fixed','percentage');
create type approval_status as enum ('pending','approved','rejected');
create type fee_frequency as enum ('monthly','quarterly','half_yearly','annual','one_time');
create type cert_type as enum ('transfer','character');

-- generic helpers
create function set_updated_at() returns trigger language plpgsql as $$
begin new.updated_at = now(); return new; end $$;

-- core tables
create table profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null default '',
  phone text,
  role user_role not null default 'accountant',
  is_active boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table academic_sessions (
  id uuid primary key default gen_random_uuid(),
  name text not null unique,
  start_date date not null,
  end_date date not null check (end_date > start_date),
  is_current boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create unique index one_current_session on academic_sessions (is_current) where is_current;

create table classes (
  id uuid primary key default gen_random_uuid(),
  name text not null unique,
  sort_order int not null unique,
  sections text[] not null default array['A'],
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table fee_heads (
  id uuid primary key default gen_random_uuid(),
  code text not null unique,
  name text not null unique,
  is_transport boolean not null default false,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table fee_structures (
  id uuid primary key default gen_random_uuid(),
  session_id uuid not null references academic_sessions(id),
  class_id uuid not null references classes(id),
  fee_head_id uuid not null references fee_heads(id),
  amount numeric(12,2) not null check (amount >= 0),
  frequency fee_frequency not null default 'monthly',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (session_id, class_id, fee_head_id)
);

create table transport_routes (
  id uuid primary key default gen_random_uuid(),
  code text not null unique,
  name text not null,
  monthly_charge numeric(12,2) not null check (monthly_charge >= 0),
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table vehicles (
  id uuid primary key default gen_random_uuid(),
  registration_no text not null unique,
  vehicle_type text,
  capacity int check (capacity > 0),
  driver_name text,
  driver_phone text,
  route_id uuid references transport_routes(id),
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create sequence admission_seq start 1;
create table students (
  id uuid primary key default gen_random_uuid(),
  admission_no text not null unique,
  session_id uuid not null references academic_sessions(id),
  class_id uuid not null references classes(id),
  section text not null default 'A',
  roll_no int,
  name text not null,
  father_name text not null,
  mother_name text,
  dob date,
  gender text check (gender in ('male','female','other')),
  address text,
  phone text,
  admission_date date not null default current_date,
  photo_path text,
  route_id uuid references transport_routes(id),
  is_active boolean not null default true,
  created_by uuid references profiles(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index students_search on students (lower(name), lower(father_name), phone);
create index students_class on students (class_id, section);

-- one row per charge (student x fee head x period)
create table student_fee_assignments (
  id uuid primary key default gen_random_uuid(),
  student_id uuid not null references students(id),
  session_id uuid not null references academic_sessions(id),
  fee_head_id uuid not null references fee_heads(id),
  period date not null,
  amount_due numeric(12,2) not null check (amount_due >= 0),
  discount_amount numeric(12,2) not null default 0 check (discount_amount >= 0),
  is_exempt boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (student_id, fee_head_id, period),
  check (discount_amount <= amount_due)
);
create index sfa_student on student_fee_assignments (student_id, session_id);

create sequence receipt_seq start 1;
create table payments (
  id uuid primary key default gen_random_uuid(),
  receipt_no text not null unique,
  student_id uuid not null references students(id),
  payment_date date not null default current_date,
  mode payment_mode not null,
  reference text,
  total_amount numeric(12,2) not null check (total_amount > 0),
  previous_balance numeric(12,2) not null default 0,
  remaining_balance numeric(12,2) not null default 0,
  status payment_status not null default 'completed',
  remarks text,
  idempotency_key text not null unique,
  received_by uuid not null references profiles(id),
  cancelled_by uuid references profiles(id),
  cancelled_at timestamptz,
  cancel_reason text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index payments_date on payments (payment_date);
create index payments_student on payments (student_id);

create table payment_allocations (
  id uuid primary key default gen_random_uuid(),
  payment_id uuid not null references payments(id),
  assignment_id uuid not null references student_fee_assignments(id),
  amount numeric(12,2) not null check (amount > 0),
  created_at timestamptz not null default now()
);
create index pa_assignment on payment_allocations (assignment_id);
create index pa_payment on payment_allocations (payment_id);

create table discounts (
  id uuid primary key default gen_random_uuid(),
  student_id uuid not null references students(id),
  fee_head_id uuid references fee_heads(id),   -- null = all heads
  kind discount_type not null,
  value numeric(12,2) not null check (value > 0),
  is_scholarship boolean not null default false,
  reason text,
  status approval_status not null default 'pending',
  requested_by uuid not null references profiles(id),
  decided_by uuid references profiles(id),
  decided_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  check (kind <> 'percentage' or value <= 100)
);

create sequence certificate_seq start 1;
create table certificates (
  id uuid primary key default gen_random_uuid(),
  certificate_no text not null unique,
  student_id uuid not null references students(id),
  kind cert_type not null,
  issued_date date not null default current_date,
  details jsonb not null default '{}',
  issued_by uuid not null references profiles(id),
  created_at timestamptz not null default now()
);

create table audit_logs (
  id bigint generated always as identity primary key,
  user_id uuid,
  action text not null,
  table_name text not null,
  record_id text,
  old_data jsonb,
  new_data jsonb,
  created_at timestamptz not null default now()
);

create table school_settings (
  id int primary key default 1 check (id = 1),
  name text not null default 'GURUKUL UNIVERSAL SCHOOL',
  tagline text not null default 'Shiksha Bhi Sanskar Bhi',
  address text, phone text, email text,
  logo_path text,
  receipt_prefix text not null default 'GUS',
  receipt_footer text default 'This is a computer generated receipt.',
  reminder_template text not null default
    'Dear Parent, fee of Rs {amount} for {student} (Class {class}) is pending. Kindly pay at the earliest. - {school}',
  currency text not null default 'INR',
  timezone text not null default 'Asia/Kolkata',
  updated_at timestamptz not null default now()
);

-- updated_at triggers
do $$ declare t text; begin
  foreach t in array array['profiles','academic_sessions','classes','fee_heads','fee_structures',
    'transport_routes','vehicles','students','student_fee_assignments','payments','discounts','school_settings']
  loop execute format('create trigger trg_%s_upd before update on %I for each row execute function set_updated_at()', t, t);
  end loop; end $$;

-- role helpers
create function is_staff() returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from profiles where id = auth.uid() and is_active) $$;
create function is_admin() returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from profiles where id = auth.uid() and is_active and role = 'admin') $$;

-- new auth user -> profile (first user becomes active admin; others inactive until admin activates)
create function handle_new_user() returns trigger language plpgsql security definer set search_path = public as $$
declare first_user boolean;
begin
  select not exists (select 1 from profiles) into first_user;
  insert into profiles (id, full_name, role, is_active)
  values (new.id, coalesce(new.raw_user_meta_data->>'full_name',''),
          case when first_user then 'admin'::user_role else 'accountant'::user_role end, first_user);
  return new;
end $$;
create trigger on_auth_user_created after insert on auth.users for each row execute function handle_new_user();

-- prevent non-admins changing role/active on profiles
create function guard_profile() returns trigger language plpgsql security definer set search_path = public as $$
begin
  if (new.role <> old.role or new.is_active <> old.is_active) and not is_admin() then
    raise exception 'Only admin can change role or status';
  end if;
  return new;
end $$;
create trigger trg_profile_guard before update on profiles for each row execute function guard_profile();

-- audit trigger
create function audit_row() returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into audit_logs (user_id, action, table_name, record_id, old_data, new_data)
  values (auth.uid(), tg_op, tg_table_name,
          coalesce((to_jsonb(new)->>'id'), (to_jsonb(old)->>'id')),
          case when tg_op <> 'INSERT' then to_jsonb(old) end,
          case when tg_op <> 'DELETE' then to_jsonb(new) end);
  return coalesce(new, old);
end $$;
do $$ declare t text; begin
  foreach t in array array['profiles','students','fee_structures','student_fee_assignments','payments',
    'discounts','certificates','school_settings','transport_routes','vehicles']
  loop execute format('create trigger trg_%s_audit after insert or update or delete on %I for each row execute function audit_row()', t, t);
  end loop; end $$;

-- block deletes on financial history
create function block_delete() returns trigger language plpgsql as $$
begin raise exception 'Deleting % records is not allowed. Cancel or deactivate instead.', tg_table_name; end $$;
do $$ declare t text; begin
  foreach t in array array['payments','payment_allocations','student_fee_assignments','discounts','certificates','audit_logs','students']
  loop execute format('create trigger trg_%s_nodel before delete on %I for each row execute function block_delete()', t, t);
  end loop; end $$;

-- balance view
create view v_assignment_balance with (security_invoker = true) as
select a.*, coalesce(p.paid,0) as paid,
  case when a.is_exempt then 0
       else greatest(a.amount_due - a.discount_amount - coalesce(p.paid,0), 0) end as outstanding
from student_fee_assignments a
left join lateral (
  select sum(pa.amount) as paid from payment_allocations pa
  join payments py on py.id = pa.payment_id and py.status = 'completed'
  where pa.assignment_id = a.id) p on true;

-- admission number
create function next_admission_no() returns text language sql security definer set search_path = public as $$
  select 'GUS/' || to_char(now() at time zone 'Asia/Kolkata','YY') || '/' || lpad(nextval('admission_seq')::text, 4, '0') $$;
alter table students alter column admission_no set default next_admission_no();

-- generate charges for a student from fee structure (+ transport route)
create function generate_student_charges(p_student_id uuid) returns int
language plpgsql security definer set search_path = public as $$
declare s students; sess academic_sessions; n int := 0; c int;
begin
  if not is_staff() then raise exception 'Not authorized'; end if;
  select * into s from students where id = p_student_id;
  select * into sess from academic_sessions where id = s.session_id;
  insert into student_fee_assignments (student_id, session_id, fee_head_id, period, amount_due)
  select s.id, s.session_id, fs.fee_head_id, g::date, fs.amount
  from fee_structures fs
  join fee_heads h on h.id = fs.fee_head_id and not h.is_transport
  cross join lateral generate_series(sess.start_date, sess.end_date - 1,
    case fs.frequency when 'monthly' then interval '1 month' when 'quarterly' then interval '3 months'
      when 'half_yearly' then interval '6 months' else interval '12 months' end) g
  where fs.session_id = s.session_id and fs.class_id = s.class_id
  on conflict (student_id, fee_head_id, period) do nothing;
  get diagnostics c = row_count; n := c;
  if s.route_id is not null then
    insert into student_fee_assignments (student_id, session_id, fee_head_id, period, amount_due)
    select s.id, s.session_id, h.id, g::date, r.monthly_charge
    from transport_routes r
    cross join (select id from fee_heads where is_transport limit 1) h
    cross join lateral generate_series(sess.start_date, sess.end_date - 1, interval '1 month') g
    where r.id = s.route_id
    on conflict (student_id, fee_head_id, period) do nothing;
    get diagnostics c = row_count; n := n + c;
  end if;
  return n;
end $$;

-- collect payment (atomic, idempotent). p_items: [{"assignment_id": "...", "amount": 500}]
create function collect_payment(p_student_id uuid, p_date date, p_mode payment_mode, p_reference text,
  p_remarks text, p_idempotency_key text, p_items jsonb) returns payments
language plpgsql security definer set search_path = public as $$
declare pay payments; it jsonb; total numeric(12,2) := 0; prev numeric(12,2); out_amt numeric(12,2);
  pref text; sess text;
begin
  if not is_staff() then raise exception 'Not authorized'; end if;
  select * into pay from payments where idempotency_key = p_idempotency_key;
  if found then return pay; end if;
  if jsonb_array_length(p_items) = 0 then raise exception 'No fee items selected'; end if;

  select coalesce(sum(outstanding),0) into prev from v_assignment_balance where student_id = p_student_id;

  for it in select * from jsonb_array_elements(p_items) loop
    perform 1 from student_fee_assignments
      where id = (it->>'assignment_id')::uuid and student_id = p_student_id for update;
    if not found then raise exception 'Invalid fee item'; end if;
    select outstanding into out_amt from v_assignment_balance where id = (it->>'assignment_id')::uuid;
    if (it->>'amount')::numeric <= 0 or (it->>'amount')::numeric > out_amt then
      raise exception 'Amount % exceeds outstanding % for an item', it->>'amount', out_amt;
    end if;
    total := total + (it->>'amount')::numeric;
  end loop;

  select receipt_prefix into pref from school_settings where id = 1;
  select name into sess from academic_sessions where is_current;
  insert into payments (receipt_no, student_id, payment_date, mode, reference, total_amount,
    previous_balance, remaining_balance, remarks, idempotency_key, received_by)
  values (coalesce(pref,'GUS') || '/' || coalesce(sess,'') || '/' || lpad(nextval('receipt_seq')::text, 6, '0'),
    p_student_id, p_date, p_mode, p_reference, total, prev, prev - total, p_remarks, p_idempotency_key, auth.uid())
  returning * into pay;

  insert into payment_allocations (payment_id, assignment_id, amount)
  select pay.id, (x->>'assignment_id')::uuid, (x->>'amount')::numeric from jsonb_array_elements(p_items) x;
  return pay;
end $$;

-- cancel payment (admin only; history kept)
create function cancel_payment(p_payment_id uuid, p_reason text) returns payments
language plpgsql security definer set search_path = public as $$
declare pay payments;
begin
  if not is_admin() then raise exception 'Only admin can cancel payments'; end if;
  if coalesce(trim(p_reason),'') = '' then raise exception 'Reason required'; end if;
  update payments set status = 'cancelled', cancelled_by = auth.uid(), cancelled_at = now(), cancel_reason = p_reason
  where id = p_payment_id and status = 'completed' returning * into pay;
  if not found then raise exception 'Payment not found or already cancelled'; end if;
  return pay;
end $$;

-- discount decision (admin only). fixed = per charge line; percentage of amount_due.
create function decide_discount(p_id uuid, p_approve boolean) returns discounts
language plpgsql security definer set search_path = public as $$
declare d discounts;
begin
  if not is_admin() then raise exception 'Only admin can approve discounts'; end if;
  update discounts set status = case when p_approve then 'approved'::approval_status else 'rejected' end,
    decided_by = auth.uid(), decided_at = now()
  where id = p_id and status = 'pending' returning * into d;
  if not found then raise exception 'Discount not pending'; end if;
  if p_approve then
    update student_fee_assignments a set discount_amount = least(a.amount_due,
      a.discount_amount + case d.kind when 'fixed' then d.value else round(a.amount_due * d.value / 100, 2) end)
    where a.student_id = d.student_id and (d.fee_head_id is null or a.fee_head_id = d.fee_head_id);
  end if;
  return d;
end $$;

-- issue certificate
create function issue_certificate(p_student_id uuid, p_kind cert_type, p_details jsonb) returns certificates
language plpgsql security definer set search_path = public as $$
declare c certificates;
begin
  if not is_staff() then raise exception 'Not authorized'; end if;
  insert into certificates (certificate_no, student_id, kind, details, issued_by)
  values ((case p_kind when 'transfer' then 'TC' else 'CC' end) || '/' || to_char(now(),'YYYY') || '/' ||
          lpad(nextval('certificate_seq')::text, 4, '0'), p_student_id, p_kind, coalesce(p_details,'{}'), auth.uid())
  returning * into c;
  return c;
end $$;

-- ================= RLS =================
do $$ declare t text; begin
  foreach t in array array['profiles','academic_sessions','classes','fee_heads','fee_structures','transport_routes',
   'vehicles','students','student_fee_assignments','payments','payment_allocations','discounts','certificates',
   'audit_logs','school_settings']
  loop execute format('alter table %I enable row level security', t); end loop; end $$;

-- profiles
create policy profiles_self_or_admin_read on profiles for select using (id = auth.uid() or is_admin());
create policy profiles_admin_update on profiles for update using (is_admin());
create policy profiles_self_update on profiles for update using (id = auth.uid());

-- config tables: staff read, admin write
do $$ declare t text; begin
  foreach t in array array['academic_sessions','classes','fee_heads','fee_structures','transport_routes','vehicles','school_settings']
  loop
    execute format('create policy %1$s_read on %1$I for select using (is_staff())', t);
    execute format('create policy %1$s_admin_ins on %1$I for insert with check (is_admin())', t);
    execute format('create policy %1$s_admin_upd on %1$I for update using (is_admin())', t);
  end loop; end $$;

-- students and charges: staff read/insert/update (no delete policy)
create policy students_read on students for select using (is_staff());
create policy students_ins on students for insert with check (is_staff());
create policy students_upd on students for update using (is_staff());
create policy sfa_read on student_fee_assignments for select using (is_staff());
create policy sfa_ins on student_fee_assignments for insert with check (is_staff());
create policy sfa_admin_upd on student_fee_assignments for update using (is_admin());

-- payments: read only; writes via RPC
create policy payments_read on payments for select using (is_staff());
create policy pa_read on payment_allocations for select using (is_staff());

-- discounts: staff can request, admin decides (via RPC)
create policy discounts_read on discounts for select using (is_staff());
create policy discounts_request on discounts for insert with check (is_staff() and status = 'pending' and requested_by = auth.uid());

create policy certificates_read on certificates for select using (is_staff());
create policy audit_admin_read on audit_logs for select using (is_admin());

-- lock function execution to signed-in users
revoke execute on all functions in schema public from anon, public;
grant execute on function is_staff(), is_admin(), next_admission_no(), generate_student_charges(uuid),
  collect_payment(uuid,date,payment_mode,text,text,text,jsonb), cancel_payment(uuid,text),
  decide_discount(uuid,boolean), issue_certificate(uuid,cert_type,jsonb) to authenticated;
revoke all on all tables in schema public from anon;

-- storage buckets (private)
insert into storage.buckets (id, name, public) values ('student-photos','student-photos',false),('school-assets','school-assets',false)
on conflict do nothing;
create policy storage_staff_read on storage.objects for select using (bucket_id in ('student-photos','school-assets') and is_staff());
create policy storage_staff_write on storage.objects for insert with check (bucket_id = 'student-photos' and is_staff());
create policy storage_admin_assets on storage.objects for all using (bucket_id = 'school-assets' and is_admin());
