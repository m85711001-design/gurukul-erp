-- Reference data only (no fake students or payments)
insert into school_settings (id) values (1) on conflict do nothing;
insert into academic_sessions (name, start_date, end_date, is_current) values ('2026-27','2026-04-01','2027-03-31',true) on conflict do nothing;
insert into classes (name, sort_order) values
 ('Nursery',1),('LKG',2),('UKG',3),('Class 1',4),('Class 2',5),('Class 3',6),('Class 4',7),('Class 5',8),('Class 6',9),('Class 7',10),('Class 8',11)
on conflict do nothing;
insert into fee_heads (code, name, is_transport) values
 ('ADM','Admission Fee',false),('TUI','Monthly Tuition Fee',false),('ANN','Annual Fee',false),('EXM','Examination Fee',false),
 ('CMP','Computer Fee',false),('DEV','Development Fee',false),('LIB','Library Fee',false),('SPT','Sports Fee',false),
 ('OTH','Other Charges',false),('BUS','Bus Fee',true)
on conflict do nothing;
