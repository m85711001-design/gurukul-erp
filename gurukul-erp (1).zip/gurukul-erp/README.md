# Gurukul Universal School ERP

Supabase project: uctqjzjnikpoqfmrskuq (migrations applied: schema, seed, hardening, dashboard_stats)

## Run the website
cd web && npm install && npm run dev

## Deploy (Vercel)
Import the `web` folder, add env vars VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY (see web/.env.example), deploy.

## First login
Open the site -> "First-time setup" -> create account. The first account becomes Admin.
After that, turn OFF "Allow new users to sign up" in Supabase Auth settings.
