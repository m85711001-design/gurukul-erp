import { useEffect, useState } from 'react'
import { supabase } from './supabase'
import { Dashboard, Students, Collect, FeeStructure, Payments } from './pages'

export default function App() {
  const [session, setSession] = useState<any>(undefined)
  const [profile, setProfile] = useState<any>(null)
  const [page, setPage] = useState('dash')

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => setSession(data.session))
    const { data: sub } = supabase.auth.onAuthStateChange((_e, s) => setSession(s))
    return () => sub.subscription.unsubscribe()
  }, [])
  useEffect(() => {
    if (!session) { setProfile(null); return }
    supabase.from('profiles').select('*').eq('id', session.user.id).single().then(({ data }) => setProfile(data))
  }, [session])

  if (session === undefined) return <div className="auth">Loading…</div>
  if (!session) return <Auth />
  if (!profile) return <div className="auth">Loading…</div>
  if (!profile.is_active) return (
    <div className="auth card"><h1>Approval pending</h1>
      <p>Your account is waiting for Admin approval.</p>
      <button className="btn" onClick={() => supabase.auth.signOut()}>Logout</button></div>)

  const admin = profile.role === 'admin'
  const nav = [['dash', 'Dashboard'], ['students', 'Students'], ['collect', 'Collect Fee'], ['payments', 'Payments'], ...(admin ? [['structure', 'Fee Structure']] : [])]
  return (
    <div className="shell">
      <nav className="side">
        <h2>GURUKUL UNIVERSAL SCHOOL</h2><small>Shiksha Bhi Sanskar Bhi</small>
        {nav.map(([k, l]) => <button key={k} className={page === k ? 'on' : ''} onClick={() => setPage(k)}>{l}</button>)}
        <button onClick={() => supabase.auth.signOut()}>Logout</button>
      </nav>
      <main>
        {page === 'dash' && <Dashboard />}
        {page === 'students' && <Students profile={profile} />}
        {page === 'collect' && <Collect />}
        {page === 'payments' && <Payments admin={admin} />}
        {page === 'structure' && admin && <FeeStructure />}
      </main>
    </div>
  )
}

function Auth() {
  const [mode, setMode] = useState<'in' | 'up'>('in')
  const [email, setEmail] = useState(''); const [pw, setPw] = useState(''); const [name, setName] = useState('')
  const [msg, setMsg] = useState<any>(null); const [busy, setBusy] = useState(false)
  const go = async () => {
    setBusy(true); setMsg(null)
    const r = mode === 'in'
      ? await supabase.auth.signInWithPassword({ email, password: pw })
      : await supabase.auth.signUp({ email, password: pw, options: { data: { full_name: name } } })
    setBusy(false)
    if (r.error) setMsg({ t: 'err', m: r.error.message })
    else if (mode === 'up' && !r.data.session) setMsg({ t: 'ok', m: 'Account created. Check your email to confirm, then login.' })
  }
  const reset = async () => {
    if (!email) return setMsg({ t: 'err', m: 'Enter your email first' })
    const { error } = await supabase.auth.resetPasswordForEmail(email, { redirectTo: window.location.origin })
    setMsg(error ? { t: 'err', m: error.message } : { t: 'ok', m: 'Password reset link sent to your email.' })
  }
  return (
    <div className="auth card">
      <h1>Gurukul School ERP</h1>
      {msg && <div className={'msg ' + msg.t}>{msg.m}</div>}
      {mode === 'up' && <div className="row"><div><label>Full name</label><input value={name} onChange={e => setName(e.target.value)} /></div></div>}
      <div className="row"><div><label>Email</label><input type="email" value={email} onChange={e => setEmail(e.target.value)} /></div></div>
      <div className="row"><div><label>Password (min 6)</label><input type="password" value={pw} onChange={e => setPw(e.target.value)} /></div></div>
      <button className="btn" disabled={busy} onClick={go} style={{ width: '100%' }}>{busy ? 'Please wait…' : mode === 'in' ? 'Login' : 'Create account'}</button>
      <p style={{ textAlign: 'center', fontSize: 13 }}>
        <a href="#" onClick={e => { e.preventDefault(); reset() }}>Forgot password?</a> ·{' '}
        <a href="#" onClick={e => { e.preventDefault(); setMode(mode === 'in' ? 'up' : 'in') }}>{mode === 'in' ? 'First-time setup' : 'Back to login'}</a>
      </p>
      <small style={{ color: '#667' }}>The very first account created becomes the Admin. Later accounts need Admin approval.</small>
    </div>
  )
}
