import { useEffect, useRef, useState } from 'react'
import { supabase, inr } from './supabase'

const Msg = ({ m }: any) => (m ? <div className={'msg ' + m.t}>{m.m}</div> : null)

export function Dashboard() {
  const [s, setS] = useState<any>(null); const [err, setErr] = useState('')
  const [adm, setAdm] = useState<any[]>([]); const [pay, setPay] = useState<any[]>([])
  useEffect(() => {
    supabase.rpc('dashboard_stats').then(({ data, error }) => error ? setErr(error.message) : setS(data))
    supabase.from('students').select('name,admission_no,admission_date,classes(name)').order('created_at', { ascending: false }).limit(5).then(r => setAdm(r.data || []))
    supabase.from('payments').select('receipt_no,total_amount,payment_date,status,students(name)').order('created_at', { ascending: false }).limit(5).then(r => setPay(r.data || []))
  }, [])
  if (err) return <div className="msg err">{err}</div>
  if (!s) return <p>Loading…</p>
  const cards: [string, any][] = [['Total Students', s.students], ['Active Students', s.active], ['Expected Fees', inr(s.expected)],
    ['Collected', inr(s.collected)], ['Pending', inr(s.pending)], ["Today's Collection", inr(s.today)], ['This Month', inr(s.month)],
    ['Bus Collected', inr(s.bus_collected)], ['Bus Due', inr(s.bus_due)], ['Defaulters', s.defaulters]]
  const max = Math.max(1, ...s.monthly.map((x: any) => Number(x.t)))
  const pct = s.expected > 0 ? Math.round((s.collected / s.expected) * 100) : 0
  return (<>
    <h1>Dashboard</h1>
    <div className="grid">{cards.map(([l, v]) => <div className="card stat" key={l}><span>{l}</span><b>{v}</b></div>)}</div>
    <div className="card"><b>Collected vs expected: {pct}%</b>
      <div style={{ background: '#e8ecf5', borderRadius: 8, height: 12, marginTop: 8 }}><div style={{ width: pct + '%', background: 'var(--gold)', height: 12, borderRadius: 8 }} /></div></div>
    <div className="card"><b>Monthly collection</b><div className="bars" style={{ marginTop: 10, marginBottom: 24 }}>
      {s.monthly.length === 0 && <small>No payments yet</small>}
      {s.monthly.map((x: any) => <div key={x.m} style={{ height: (Number(x.t) / max) * 100 + '%' }}><span>{x.m.slice(2)}</span></div>)}</div></div>
    <div className="card"><b>Class-wise students</b><table><tbody>{s.class_counts.map((c: any) => <tr key={c.name}><td>{c.name}</td><td>{c.n}</td></tr>)}</tbody></table></div>
    <div className="card"><b>Recent admissions</b><table><tbody>{adm.map((a, i) => <tr key={i}><td>{a.name}</td><td>{a.classes?.name}</td><td>{a.admission_no}</td></tr>)}</tbody></table></div>
    <div className="card"><b>Recent payments</b><table><tbody>{pay.map((p, i) => <tr key={i}><td>{p.students?.name}</td><td>{p.receipt_no}</td><td>{inr(p.total_amount)}</td></tr>)}</tbody></table></div>
  </>)
}

const useRef0 = () => {
  const [classes, setClasses] = useState<any[]>([]); const [session, setSession] = useState<any>(null)
  useEffect(() => {
    supabase.from('classes').select('*').order('sort_order').then(r => setClasses(r.data || []))
    supabase.from('academic_sessions').select('*').eq('is_current', true).single().then(r => setSession(r.data))
  }, [])
  return { classes, session }
}

export function Students({ profile }: any) {
  const { classes, session } = useRef0()
  const [rows, setRows] = useState<any[]>([]); const [q, setQ] = useState(''); const [page, setPage] = useState(0)
  const [count, setCount] = useState(0); const [form, setForm] = useState<any>(null); const [m, setM] = useState<any>(null)
  const [busy, setBusy] = useState(false); const PS = 20
  const load = async () => {
    let qb = supabase.from('students').select('*, classes(name)', { count: 'exact' }).order('created_at', { ascending: false }).range(page * PS, page * PS + PS - 1)
    const t = q.trim().replace(/[,()%]/g, '')
    if (t) qb = qb.or(`name.ilike.%${t}%,father_name.ilike.%${t}%,phone.ilike.%${t}%,admission_no.ilike.%${t}%`)
    const { data, count, error } = await qb
    if (error) setM({ t: 'err', m: error.message }); else { setRows(data || []); setCount(count || 0) }
  }
  useEffect(() => { load() }, [page, q])
  const save = async () => {
    if (!form.name || !form.father_name || !form.class_id) return setM({ t: 'err', m: 'Name, father name and class are required' })
    setBusy(true)
    const { id, classes: _c, ...rest } = form
    const body = { ...rest, session_id: session.id, created_by: profile.id, dob: rest.dob || null, roll_no: rest.roll_no ? Number(rest.roll_no) : null }
    let r: any
    if (id) r = await supabase.from('students').update(body).eq('id', id).select().single()
    else { delete body.admission_no; r = await supabase.from('students').insert(body).select().single() }
    if (r.error) { setBusy(false); return setM({ t: 'err', m: r.error.message }) }
    const g = await supabase.rpc('generate_student_charges', { p_student_id: r.data.id })
    setBusy(false)
    setM(g.error ? { t: 'err', m: g.error.message } : { t: 'ok', m: `Saved (${r.data.admission_no}). ${g.data} fee entries created.` })
    setForm(null); load()
  }
  const toggle = async (s: any) => { await supabase.from('students').update({ is_active: !s.is_active }).eq('id', s.id); load() }
  const f = (k: string, label: string, type = 'text') => <div><label>{label}</label><input type={type} value={form[k] ?? ''} onChange={e => setForm({ ...form, [k]: e.target.value })} /></div>
  return (<>
    <h1>Students</h1><Msg m={m} />
    {form ? (<div className="card">
      <div className="row">{f('name', 'Student name *')}{f('father_name', 'Father name *')}{f('mother_name', 'Mother name')}{f('dob', 'Date of birth', 'date')}
        <div><label>Gender</label><select value={form.gender || ''} onChange={e => setForm({ ...form, gender: e.target.value || null })}><option value="">-</option><option value="male">Male</option><option value="female">Female</option></select></div>
        {f('phone', 'Mobile')}
        <div><label>Class *</label><select value={form.class_id || ''} onChange={e => setForm({ ...form, class_id: e.target.value })}><option value="">Select</option>{classes.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}</select></div>
        {f('section', 'Section')}{f('roll_no', 'Roll no', 'number')}{f('address', 'Address')}</div>
      <button className="btn" disabled={busy} onClick={save}>{busy ? 'Saving…' : 'Save'}</button>{' '}
      <button className="btn ghost" onClick={() => setForm(null)}>Cancel</button></div>)
    : (<div className="card"><div className="row"><input placeholder="Search name, father, mobile, admission no" value={q} onChange={e => { setPage(0); setQ(e.target.value) }} />
      <div><button className="btn gold" onClick={() => setForm({ section: 'A' })}>+ Add student</button></div></div>
      <div style={{ overflowX: 'auto' }}><table><thead><tr><th>Adm. no</th><th>Name</th><th>Father</th><th>Class</th><th>Mobile</th><th></th></tr></thead>
        <tbody>{rows.map(s => <tr key={s.id} style={{ opacity: s.is_active ? 1 : .5 }}><td>{s.admission_no}</td><td>{s.name}</td><td>{s.father_name}</td><td>{s.classes?.name} {s.section}</td><td>{s.phone}</td>
          <td><a href="#" onClick={e => { e.preventDefault(); setForm(s) }}>Edit</a> · <a href="#" onClick={e => { e.preventDefault(); toggle(s) }}>{s.is_active ? 'Deactivate' : 'Activate'}</a></td></tr>)}</tbody></table></div>
      <p>{count} students · <button className="btn ghost" disabled={page === 0} onClick={() => setPage(page - 1)}>Prev</button>{' '}
        <button className="btn ghost" disabled={(page + 1) * PS >= count} onClick={() => setPage(page + 1)}>Next</button></p></div>)}
  </>)
}

export function FeeStructure() {
  const { classes, session } = useRef0()
  const [heads, setHeads] = useState<any[]>([]); const [cid, setCid] = useState(''); const [vals, setVals] = useState<any>({}); const [m, setM] = useState<any>(null)
  const defFreq: any = { ADM: 'one_time', TUI: 'monthly', ANN: 'annual', EXM: 'half_yearly', BUS: 'monthly' }
  useEffect(() => { supabase.from('fee_heads').select('*').eq('is_transport', false).order('name').then(r => setHeads(r.data || [])) }, [])
  useEffect(() => {
    if (!cid || !session) return
    supabase.from('fee_structures').select('*').eq('class_id', cid).eq('session_id', session.id).then(r => {
      const v: any = {}; (r.data || []).forEach(x => v[x.fee_head_id] = { amount: x.amount, frequency: x.frequency }); setVals(v)
    })
  }, [cid, session])
  const save = async () => {
    const rows = heads.filter(h => vals[h.id]?.amount !== undefined && vals[h.id].amount !== '').map(h => ({
      session_id: session.id, class_id: cid, fee_head_id: h.id, amount: Number(vals[h.id].amount), frequency: vals[h.id].frequency || defFreq[h.code] || 'annual' }))
    const { error } = await supabase.from('fee_structures').upsert(rows, { onConflict: 'session_id,class_id,fee_head_id' })
    setM(error ? { t: 'err', m: error.message } : { t: 'ok', m: 'Fee structure saved. For existing students, press Edit → Save on the student to create new fee entries.' })
  }
  return (<><h1>Fee Structure ({session?.name})</h1><Msg m={m} />
    <div className="card"><div className="row"><div><label>Class</label><select value={cid} onChange={e => setCid(e.target.value)}><option value="">Select class</option>{classes.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}</select></div></div>
      {cid && <><table><thead><tr><th>Fee head</th><th>Amount ₹</th><th>Plan</th></tr></thead><tbody>
        {heads.map(h => <tr key={h.id}><td>{h.name}</td>
          <td><input type="number" min="0" value={vals[h.id]?.amount ?? ''} onChange={e => setVals({ ...vals, [h.id]: { ...vals[h.id], amount: e.target.value } })} /></td>
          <td><select value={vals[h.id]?.frequency || defFreq[h.code] || 'annual'} onChange={e => setVals({ ...vals, [h.id]: { ...vals[h.id], frequency: e.target.value } })}>
            <option value="monthly">Monthly</option><option value="quarterly">Quarterly</option><option value="half_yearly">Half-yearly</option><option value="annual">Annual</option><option value="one_time">One time</option></select></td></tr>)}
      </tbody></table><br /><button className="btn" onClick={save}>Save fee structure</button></>}</div></>)
}

export function Collect() {
  const [q, setQ] = useState(''); const [res, setRes] = useState<any[]>([]); const [st, setSt] = useState<any>(null)
  const [items, setItems] = useState<any[]>([]); const [sel, setSel] = useState<any>({}); const [mode, setMode] = useState('cash')
  const [ref, setRef] = useState(''); const [date, setDate] = useState(new Date().toISOString().slice(0, 10))
  const [m, setM] = useState<any>(null); const [busy, setBusy] = useState(false); const [done, setDone] = useState<string | null>(null)
  const key = useRef(crypto.randomUUID())
  const search = async () => {
    const t = q.trim().replace(/[,()%]/g, ''); if (!t) return
    const { data } = await supabase.from('students').select('id,name,father_name,admission_no,classes(name),section').eq('is_active', true)
      .or(`name.ilike.%${t}%,father_name.ilike.%${t}%,phone.ilike.%${t}%,admission_no.ilike.%${t}%`).limit(10)
    setRes(data || [])
  }
  const pick = async (s: any) => {
    setSt(s); setRes([]); setSel({}); setDone(null)
    const { data } = await supabase.from('v_assignment_balance').select('*, fee_heads(name)').eq('student_id', s.id).gt('outstanding', 0).order('period')
    setItems(data || [])
  }
  const total = Object.values(sel).reduce((a: number, v: any) => a + Number(v || 0), 0)
  const toggle = (it: any) => { const n = { ...sel }; if (n[it.id] !== undefined) delete n[it.id]; else n[it.id] = it.outstanding; setSel(n) }
  const pay = async () => {
    if (busy || total <= 0) return
    setBusy(true); setM(null)
    const payload = Object.entries(sel).map(([id, amount]) => ({ assignment_id: id, amount: Number(amount) }))
    const { data, error } = await supabase.rpc('collect_payment', { p_student_id: st.id, p_date: date, p_mode: mode, p_reference: ref || null, p_remarks: null, p_idempotency_key: key.current, p_items: payload })
    setBusy(false)
    if (error) return setM({ t: 'err', m: error.message })
    key.current = crypto.randomUUID(); setDone(data.id); pick(st)
  }
  if (done) return <><button className="btn ghost" onClick={() => { setDone(null); setSt(null) }}>← New collection</button><br /><br /><Receipt id={done} /></>
  const mon = (d: string) => new Date(d).toLocaleDateString('en-IN', { month: 'short', year: '2-digit' })
  return (<><h1>Collect Fee</h1><Msg m={m} />
    <div className="card"><div className="row"><input placeholder="Search student (name, father, mobile, admission no)" value={q} onChange={e => setQ(e.target.value)} onKeyDown={e => e.key === 'Enter' && search()} />
      <div><button className="btn" onClick={search}>Search</button></div></div>
      {res.map(s => <div key={s.id}><a href="#" onClick={e => { e.preventDefault(); pick(s) }}>{s.name} — {s.father_name} — {s.classes?.name} {s.section} — {s.admission_no}</a></div>)}</div>
    {st && <div className="card"><b>{st.name}</b> · {st.classes?.name} {st.section} · {st.admission_no}
      <p>Outstanding: <b>{inr(items.reduce((a, i) => a + Number(i.outstanding), 0))}</b></p>
      {items.length === 0 ? <p>No dues. (If fee entries are missing, set the Fee Structure then edit & save the student.)</p> : <>
        <table><thead><tr><th></th><th>Fee</th><th>Period</th><th>Due</th><th>Pay ₹</th></tr></thead><tbody>
          {items.map(it => <tr key={it.id}><td><input type="checkbox" checked={sel[it.id] !== undefined} onChange={() => toggle(it)} style={{ width: 'auto' }} /></td>
            <td>{it.fee_heads?.name}</td><td>{mon(it.period)}</td><td>{inr(it.outstanding)}</td>
            <td>{sel[it.id] !== undefined && <input type="number" min="1" max={it.outstanding} value={sel[it.id]} onChange={e => setSel({ ...sel, [it.id]: e.target.value })} />}</td></tr>)}</tbody></table><br />
        <div className="row"><div><label>Mode</label><select value={mode} onChange={e => setMode(e.target.value)}><option value="cash">Cash</option><option value="upi">UPI</option><option value="bank_transfer">Bank transfer</option><option value="cheque">Cheque</option><option value="other">Other</option></select></div>
          <div><label>Reference / Txn no</label><input value={ref} onChange={e => setRef(e.target.value)} /></div>
          <div><label>Date</label><input type="date" value={date} onChange={e => setDate(e.target.value)} /></div></div>
        <button className="btn gold" disabled={busy || total <= 0} onClick={pay}>{busy ? 'Saving…' : `Collect ${inr(total)}`}</button></>}</div>}
  </>)
}

export function Receipt({ id }: { id: string }) {
  const [p, setP] = useState<any>(null); const [set, setSet] = useState<any>({}); const [thermal, setThermal] = useState(false)
  useEffect(() => {
    supabase.from('payments').select('*, students(name,father_name,admission_no,section,classes(name)), payment_allocations(amount, student_fee_assignments(period, fee_heads(name)))').eq('id', id).single().then(r => setP(r.data))
    supabase.from('school_settings').select('*').eq('id', 1).single().then(r => setSet(r.data || {}))
  }, [id])
  if (!p) return <p>Loading receipt…</p>
  const s = p.students
  return (<>
    <div className="no-print" style={{ marginBottom: 10 }}><button className="btn" onClick={() => window.print()}>Print / Save PDF</button>{' '}
      <button className="btn ghost" onClick={() => setThermal(!thermal)}>{thermal ? 'A4 layout' : 'Thermal layout'}</button></div>
    <div className={'receipt' + (thermal ? ' thermal' : '')}>
      <h2>{set.name}</h2><p><i>{set.tagline}</i></p>{set.address && <p>{set.address}</p>}<hr />
      <p style={{ textAlign: 'left' }}>Receipt No: <b>{p.receipt_no}</b>{p.status !== 'completed' && <b style={{ color: 'red' }}> ({p.status.toUpperCase()})</b>}</p>
      <p style={{ textAlign: 'left' }}>Date: {new Date(p.payment_date).toLocaleDateString('en-IN')} · Mode: {p.mode}{p.reference ? ' · Ref: ' + p.reference : ''}</p>
      <p style={{ textAlign: 'left' }}>Student: <b>{s.name}</b> ({s.admission_no})</p>
      <p style={{ textAlign: 'left' }}>Father: {s.father_name} · Class: {s.classes?.name} {s.section}</p>
      <table><thead><tr><th>Particulars</th><th>Amount</th></tr></thead><tbody>
        {p.payment_allocations.map((a: any, i: number) => <tr key={i}><td>{a.student_fee_assignments.fee_heads.name} ({new Date(a.student_fee_assignments.period).toLocaleDateString('en-IN', { month: 'short', year: '2-digit' })})</td><td>{inr(a.amount)}</td></tr>)}
        <tr><td><b>Total paid</b></td><td><b>{inr(p.total_amount)}</b></td></tr></tbody></table>
      <p style={{ textAlign: 'left' }}>Previous balance: {inr(p.previous_balance)} · Remaining balance: {inr(p.remaining_balance)}</p>
      <br /><p style={{ textAlign: 'right' }}>Authorised signature</p><p>{set.receipt_footer}</p></div></>)
}

export function Payments({ admin }: { admin: boolean }) {
  const [rows, setRows] = useState<any[]>([]); const [view, setView] = useState<string | null>(null); const [m, setM] = useState<any>(null)
  const load = () => supabase.from('payments').select('id,receipt_no,payment_date,total_amount,mode,status,students(name,admission_no)').order('created_at', { ascending: false }).limit(50).then(r => setRows(r.data || []))
  useEffect(() => { load() }, [])
  const cancel = async (id: string) => {
    const reason = window.prompt('Reason for cancelling this payment?'); if (!reason) return
    const { error } = await supabase.rpc('cancel_payment', { p_payment_id: id, p_reason: reason })
    setM(error ? { t: 'err', m: error.message } : { t: 'ok', m: 'Payment cancelled (record kept).' }); load()
  }
  if (view) return <><button className="btn ghost" onClick={() => setView(null)}>← Back</button><br /><br /><Receipt id={view} /></>
  return (<><h1>Payments</h1><Msg m={m} /><div className="card" style={{ overflowX: 'auto' }}><table><thead><tr><th>Receipt</th><th>Date</th><th>Student</th><th>Amount</th><th>Mode</th><th>Status</th><th></th></tr></thead>
    <tbody>{rows.map(p => <tr key={p.id}><td>{p.receipt_no}</td><td>{p.payment_date}</td><td>{p.students?.name}</td><td>{inr(p.total_amount)}</td><td>{p.mode}</td><td>{p.status}</td>
      <td><a href="#" onClick={e => { e.preventDefault(); setView(p.id) }}>Receipt</a>{admin && p.status === 'completed' && <> · <a href="#" onClick={e => { e.preventDefault(); cancel(p.id) }}>Cancel</a></>}</td></tr>)}</tbody></table></div></>)
}
